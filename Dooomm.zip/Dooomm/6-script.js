
contador.id = 'contador';
contador.textContent = '0';


const botaoIniciar = document.createElement('button');
botaoIniciar.textContent = 'Iniciar';

const botaoParar = document.createElement('button');
botaoParar.textContent = 'Parar';


document.body.append(contador, botaoIniciar, botaoParar);

let intervalo = null;

botaoIniciar.addEventListener('click', () => {
  if (intervalo !== null) return;

  intervalo = setInterval(() => {
    contador.textContent = Number(contador.textContent) + 1;
  }, 1000);
});


botaoParar.addEventListener('click', () => {
  clearInterval(intervalo);
  intervalo = null;
});
