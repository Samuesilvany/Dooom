
const botao = document.createElement('button');
botao.textContent = 'Adicionar';
document.body.appendChild(botao);


const lista = document.createElement('ul');
lista.id = 'lista-tarefas';
document.body.appendChild(lista);


botao.addEventListener('click', () => {
  const novaTarefa = document.createElement('li');
  novaTarefa.textContent = 'Nova tarefa';
  lista.appendChild(novaTarefa);
});


lista.addEventListener('click', (evento) => {
  if (evento.target.tagName === 'LI') {
    evento.target.style.color = 'green';
  }
});
