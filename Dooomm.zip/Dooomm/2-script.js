
const botao = document.createElement('button');
botao.textContent = 'Adicionar';
document.body.appendChild(botao);


const lista = document.createElement('ul');
lista.id = 'lista-tarefas';
document.body.appendChild(lista);

botao.addEventListener('click', () => {
  const novaTarefa = document.createElement('li');
  novaTarefa.textContent = 'Nova tarefa';
  lista.appendChild(novaTarefa);
});


lista.addEventListener('click', (event) => {
  if (event.target.tagName === 'LI') {
    event.target.style.color = 'green';
  }
});


lista.addEventListener('dblclick', (event) => {
  if (event.target.tagName === 'LI') {
    event.target.remove(); 
  }
});
