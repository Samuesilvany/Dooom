
const inputNome = document.createElement('input');
inputNome.type = 'text';
inputNome.placeholder = 'Nome';

const inputEmail = document.createElement('input');
inputEmail.type = 'email';
inputEmail.placeholder = 'Email';

const botao = document.createElement('button');
botao.textContent = 'Mostrar';

const saida = document.createElement('p');
saida.id = 'saida';


document.body.append(inputNome, inputEmail, botao, saida);

botao.addEventListener('click', () => {
  const nome = inputNome.value.trim();
  const email = inputEmail.value.trim();

  saida.textContent = `Nome: ${nome}, Email: ${email}`;
});
