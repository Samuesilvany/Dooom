
const inputNome = document.createElement('input');
inputNome.type = 'text';
inputNome.placeholder = 'Nome';

const inputEmail = document.createElement('input');
inputEmail.type = 'email';
inputEmail.placeholder = 'Email';


const botaoEnviar = document.createElement('button');
botaoEnviar.textContent = 'Enviar';

const botaoResetar = document.createElement('button');
botaoResetar.textContent = 'Resetar';


const saida = document.createElement('p');
saida.id = 'saida';


document.body.append(inputNome, inputEmail, botaoEnviar, botaoResetar, saida);


botaoEnviar.addEventListener('click', () => {
  const nome = inputNome.value.trim();
  const email = inputEmail.value.trim();

  if (nome === '' || email === '') {
    saida.textContent = 'Preencha todos os campos!';
    saida.style.color = 'red';
  } else {
    saida.textContent = 'Formulário enviado com sucesso!';
    saida.style.color = 'green';
  }
});


botaoResetar.addEventListener('click', () => {
  inputNome.value = '';
  inputEmail.value = '';
  saida.textContent = '';
});
